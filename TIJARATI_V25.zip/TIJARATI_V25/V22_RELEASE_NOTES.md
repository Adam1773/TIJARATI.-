# TIJARATI / TRADEVERSE V22

## V22 changes
- Adds a database migration enforcing one platform-owner role and restricting that role to the configured owner email `adamsaadoutlook@gmail.com`.
- Adds a one-time owner bootstrap script that locates the already-registered Supabase Auth user by email; it does not create or embed a password.
- Retains the marketplace, merchant/staff, courier and delivery-company workflows, order flow, realtime updates, four-language interface foundation, AI assistant/photo-analysis flow, and Android CI workflow from V21.
- Adds smoke checks for the single-owner migration and bootstrap script.

## Important operational requirements
- This is a source package, not a built APK. The Android workflow must run in the user's GitHub repository before an APK artifact exists.
- The new migration has NOT been applied to the live Supabase project by packaging this ZIP. Apply migrations in order after reviewing the SQL and taking a database backup.
- The owner account must already exist in Supabase Auth. Then run `supabase/bootstrap_owner.sql` once using an authorized SQL Editor session. The migration blocks any other email from receiving `owner` in `user_roles` and a partial unique index prevents a second owner.
- The existing client-side UI translations are still a partial interface translation system, not a verified full translation of every dynamic/server/database message. Native Sorani and Kurmanji review remains required.
- The AI assistant Edge Function requires `OPENAI_API_KEY` in Supabase Edge Function Secrets. It is an authenticated assistant and product-photo helper; it does not execute purchases, edit inventory, or administer accounts autonomously.
- Do not put passwords, Supabase service-role keys, or OpenAI keys in client files, ZIP files, GitHub source, or chat.
- Cloudflare WAF, push notifications, production signing, payment gateway, and full end-to-end QA remain external/unfinished tasks.
