# TIJARATI — تجارتي

مشروع سوق متعدد التجار للعراق (جملة ومفرد)، مبني بواجهة ويب قابلة للتغليف كتطبيق Android عبر Capacitor، ومتصل بمشروع Supabase القائم.

## ما أُنجز في هذه النسخة
- تسجيل حساب وتسجيل دخول بالبريد وكلمة المرور، مع حفظ لغة المستخدم.
- سوق المنتجات المعتمدة والمنشورة، بحث وتصفية حسب المدينة والقسم، وإظهار منتجات المتاجر التي لديها تغطية توصيل نشطة إلى مدينة المشتري.
- إنشاء متجر، إضافة منتجات بأسعار IQD أو USD، مراجعة المدير، وإرفاق صور JPG/PNG/WEBP حتى 5MB.
- سلة من متجر واحد وعملة واحدة، وطلب دفع عند الاستلام مع تسعير ومخزون وتغطية محسوبة داخل قاعدة البيانات.
- لوحة مالك لمراجعة المتاجر والمنتجات، وإدارة مندوبي منصة تجارتي وشركات التوصيل وإسناد الطلبات.
- لوحات مندوب المنصة ومندوب المتجر وشركة التوصيل، وتحديث حالات الاستلام والتسليم وتحصيل الدفع عند الاستلام.
- إدارة موظفي المتجر بصلاحيات مستقلة لإدارة الطلبات والمنتجات والرسائل.
- مراسلات بين المشتري والتاجر، وإشعارات حساب مع تحديد الرسائل والإشعارات كمقروءة.
- واجهة لغات أساسية للعربية والإنجليزية والسورانية والكرمانجية؛ ما زالت بعض الرسائل التفصيلية والنصوص الثانوية تحتاج استكمال الترجمة والمراجعة اللغوية.
- PWA، تهيئة Capacitor للأندرويد، ورؤوس أمان وCSP.

## قاعدة البيانات والحماية
- Supabase project ref: `qbqlmqyxkotxoowejyso`.
- 42/42 جدولاً عاماً مع RLS مفعّل.
- لا توجد وظائف SECURITY DEFINER قابلة للتنفيذ بواسطة `anon`، وجميع وظائف SECURITY DEFINER التي فُحصت تضبط `search_path` فارغاً.
- صلاحيات الرسائل محدودة للمشاركين، وتحديث الرسائل والإشعارات مسموح به على عمود `read_at` فقط.
- صور المنتجات في bucket عام للقراءة، لكن الرفع والحذف محصوران بمالك المتجر أو الموظف ذي صلاحية إدارة المنتجات.
- تحديد معدل إنشاء الطلبات: خمسة طلبات لكل مشتري خلال عشر دقائق.
- ما زال Supabase Security Advisor يعرض تحذيرات عن وظائف SECURITY DEFINER القابلة للتنفيذ من `authenticated`؛ هذه الوظائف تحتوي فحوصاً داخلية للمالك/المشارك/المندوب. كما أن حماية كلمات المرور المسربة غير مفعّلة على الخطة الحالية.
- لا توجد حماية كاملة 100%؛ يجب إجراء اختبار قبول وأمن مستقل قبل فتح التسجيل العام.

## تشغيل الواجهة محلياً
يتطلب Node.js 20 أو أحدث واتصالاً لتنزيل حزم npm:

```bash
npm install
npm test
npm run dev
```

لبناء ملفات الويب:

```bash
npm run build
```

## إنشاء APK
يتطلب JDK 21 وAndroid SDK:

```bash
npm install
npm test
npm run build
npx cap add android
npx cap sync android
cd android
./gradlew assembleDebug
```

يوجد سير عمل GitHub Actions في `.github/workflows/android-apk.yml` لبناء APK تجريبي ورفعه كـ artifact. لم يُنشأ مستودع GitHub للمشروع ولم تُشغّل عملية CI، كما أن بيئة التنفيذ الحالية لا تحتوي Android SDK أو Gradle ولا `node_modules`؛ لذلك **لا يوجد APK مبني حتى الآن**. راجع `BUILD_APK.md`.

## Cloudflare WAF
قواعد الإعداد المقترحة في `security/CLOUDFLARE_WAF_SETUP.md`. **WAF الخارجي غير مفعّل** لعدم توفر نطاق/Zone عام وصلاحية Cloudflare. كما أن نطاق Supabase الافتراضي `*.supabase.co` لا يصبح محمياً تلقائياً بمجرد حماية نطاق واجهة التطبيق.

## حدود ما قبل الإطلاق
- الترجمة الأساسية موجودة، لكن يلزم تدقيق لغوي وإكمال جميع رسائل الخطأ والحالات والنصوص الثانوية باللغات الأربع.
- لا تزال هناك حاجة لاختبارات قبول حقيقية بحسابات مشتري وتاجر وموظف ومندوب وشركة توصيل منفصلة.
- يلزم بناء APK وتثبيته واختبار صلاحيات الكاميرا/الملفات والروابط العميقة والإشعارات على أجهزة Android فعلية.
- الإشعارات الحالية داخل التطبيق؛ لا يوجد بعد دفع إشعارات FCM/APNs.
- المراسلات تعمل عبر قاعدة البيانات، لكن تم تفعيل Supabase Realtime للرسائل والإشعارات والطلبات وإسنادات التوصيل، ولا توجد مرفقات للمحادثات بعد.
- مسار الدفع الحالي هو الدفع عند الاستلام فقط.

ملفات `supabase/archive/` تاريخية ولا تعاد على قاعدة البيانات الحالية. ملفات migrations المؤرخة في `supabase/migrations/` توثق تغييرات قاعدة البيانات التي طُبقت على المشروع المرتبط.


## Translation and AI assistant (V6 work)
- Added a four-language interface foundation for Arabic, English, Sorani and Kurmanji, including language direction (RTL/LTR). User-entered product and message content is intentionally not auto-translated.
- Added an in-app TIJARATI AI assistant panel. It calls the authenticated `tijarati-assistant` Supabase Edge Function; the OpenAI key is server-side only.
- See `AI_SETUP.md` for deployment and secret configuration. The AI service will not answer until the Edge Function is deployed and `OPENAI_API_KEY` is configured.
- Machine translations require review by native Sorani and Kurmanji speakers before public release.


## AI copilot (V7)
The AI copilot now accepts optional product/customer images, can analyze a merchant product photo and prefill editable title and description suggestions, and provides photo/listing/catalog presentation advice. The authenticated `tijarati-assistant` Edge Function was deployed to the connected Supabase project on 19 November 2026 and verified ACTIVE with JWT verification. The `OPENAI_API_KEY` Edge Function secret is not configured yet; follow `AI_SETUP.md` to activate AI. See that file for privacy and limits. The merchant must review and confirm all listing details; the AI does not publish or change prices/stock.

## V20 consolidated release
See `V20_RELEASE_NOTES.md` for the consolidated feature inventory, verified scope, and outstanding production requirements. V20 is a source-package milestone; it does not contain a built APK and does not imply that pending integrations (such as the OpenAI secret, Cloudflare WAF, push notifications, or release signing) are complete.


## V22 single-owner security
V22 adds `20261119020000_lock_single_platform_owner_email.sql` to constrain the `owner` role to `adamsaadoutlook@gmail.com` and to one row only in `user_roles`. After the account has registered in Supabase Auth, run `supabase/bootstrap_owner.sql` once from the authorized Supabase SQL Editor. This package does not apply the migration to the live database automatically. See `V22_RELEASE_NOTES.md`.
