# TIJARATI V20 — consolidated development package

This V20 package consolidates the verified work present in the supplied V11 source and the development decisions recorded for TIJARATI. It is a source release, not a claim that every planned feature is production-complete.

## Included and verified in the source

- Multi-vendor Iraqi marketplace foundation for wholesale and retail.
- Arabic, English, Sorani Kurdish and Kurmanji language foundations with RTL/LTR direction support. Some secondary strings still need native-speaker review and completion.
- IQD and USD product pricing.
- Customer, merchant/store, store-staff, platform-owner, platform delivery agent, store delivery agent and delivery-company workflows represented in the application/database foundation.
- Product review/publishing flow, city and delivery-coverage filtering, product image upload permissions, shopping cart and cash-on-delivery order flow.
- Order numbering, order status handling, delivery assignment and delivery status transition controls.
- Store staff permissions, buyer/merchant messaging and in-app notifications.
- Supabase RLS and database migrations, including owner-only platform administration, restrictions on anonymous writes, message/notification update restrictions, transactional order rate limiting, delivery-company controls and delivery service-area assignment.
- Supabase Edge Function `tijarati-assistant` integration for authenticated AI assistance and product-image analysis/listing suggestions. The function was previously deployed ACTIVE with JWT verification; the `OPENAI_API_KEY` secret still must be configured by the project owner in Supabase before AI requests can succeed.
- Capacitor Android configuration and GitHub Actions workflow for producing a debug APK.
- Security guidance and Cloudflare WAF setup instructions.

## Explicitly not complete / requires owner action or external validation

- No APK is included in this ZIP. The GitHub Actions workflow must be run successfully to produce the APK artifact.
- No signed release APK/AAB or Google Play signing key is included.
- `OPENAI_API_KEY` is not embedded in the project and must be configured as a Supabase Edge Function secret. Never commit the key to GitHub or send it in chat.
- Cloudflare WAF is not active; it requires a domain/zone and DNS configuration.
- Full translation coverage and native Sorani/Kurmanji proofreading remain necessary.
- AI-assisted image analysis and listing suggestions exist; automatic photo capture/editing, autonomous publishing, automatic price changes and fully automated store operations are not implemented. Merchant approval remains required.
- Push notifications, chat attachments, online payment gateways and production-grade end-to-end acceptance/security testing are not included as completed features.
- Do not describe the system as 100% secure. Review Supabase Security Advisor findings and test all role permissions before public launch.

## Build checks

Run from this directory with Node.js 20+ and network access:

```bash
npm install
npm test
npm run build
```

For Android, use JDK 21 and Android SDK, then run the documented workflow in `BUILD_APK.md` or GitHub Actions workflow `.github/workflows/android-apk.yml`.

## V20 release integrity

The package preserves the supplied V11 application source and database migrations while adding this consolidated V20 release record. The release label does not imply that the outstanding items above have been completed.
