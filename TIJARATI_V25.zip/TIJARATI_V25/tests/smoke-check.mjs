import { readFileSync, existsSync } from 'node:fs';
import assert from 'node:assert/strict';
const root = new URL('../', import.meta.url);
const read = p => readFileSync(new URL(p, root), 'utf8');
const html = read('index.html');
const js = read('app.js');
const pkg = JSON.parse(read('package.json'));
const cap = JSON.parse(read('capacitor.config.json'));
const workflow = read('.github/workflows/android-apk.yml');
assert.match(html, /src="\.\/app\.js"/);
assert.match(html, /id="messages"/);
assert.match(html, /id="categoryTiles"/);
assert.match(html, /id="stores"/);
assert.match(html, /ابحث عن منتج أو متجر أو خدمة/);
assert.match(html, /id="assistant"/);
assert.match(html, /id="aiPrompt"/);
assert.match(html, /id="courier"/);
assert.match(html, /id="company"/);
assert.match(html, /id="pimage"/);
assert.match(js, /@supabase\/supabase-js/);
assert.match(js, /place_order_from_cart/);
assert.match(js, /buyer_id===user\.id/);
assert.match(js, /store_delivery_areas/);
assert.match(js, /function renderCategoryTiles/);
assert.match(js, /function loadStores/);
assert.match(js, /function renderStores/);
assert.match(js, /categoryIcon/);
assert.match(js, /p\.categories\?\.name_ar/);
for (const rpc of ['store_owner_add_staff','store_owner_add_delivery_agent','store_owner_assign_delivery_order','admin_register_delivery_company','admin_assign_company_order','delivery_company_list_my_orders','delivery_agent_list_my_orders','update_store_order_status']) assert.ok(js.includes(rpc), `Missing RPC integration: ${rpc}`);
for (const lang of ['ar','en','ckb','kmr']) assert.ok(js.includes(`${lang}:`), `Missing language pack: ${lang}`);
assert.match(js, /product-images/);
assert.match(js, /notifications/);
assert.match(js, /tijarati-assistant/);
assert.match(js, /translateStaticText/);
assert.match(js, /staticI18n/);
assert.match(js, /postgres_changes/);
assert.equal(cap.webDir, 'dist');
assert.ok(pkg.dependencies['@capacitor/android']);
assert.ok(pkg.dependencies['@supabase/supabase-js']);
assert.ok(existsSync(new URL('public/_headers', root)));
assert.ok(existsSync(new URL('security/CLOUDFLARE_WAF_SETUP.md', root)));
for (const migration of [
 'supabase/migrations/20261119014049_delivery_companies_and_product_image_storage.sql',
 'supabase/migrations/20261119014113_revoke_anonymous_delivery_company_rpcs.sql',
 'supabase/migrations/20261119014253_allow_store_message_staff_permissions.sql',
 'supabase/migrations/20261119014323_restrict_message_and_notification_updates.sql',
 'supabase/migrations/20261119014426_store_delivery_agent_workflows.sql',
 'supabase/migrations/20261119014509_allow_product_staff_upload_images.sql',
 'supabase/migrations/20261119014855_allow_out_for_delivery_order_status.sql',
 'supabase/migrations/20261119014914_enforce_delivery_service_area_assignment.sql',
 'supabase/migrations/20261119014943_enable_realtime_for_app_activity.sql',
 'supabase/migrations/20261119015052_enforce_delivery_status_transitions.sql'
]) assert.ok(existsSync(new URL(migration, root)), `Missing migration: ${migration}`);
assert.match(workflow, /npm test/);
assert.match(workflow, /android\/app\/build\/outputs\/apk\/debug\/app-debug\.apk/);
assert.doesNotMatch(js, /service_role/i);
const aiFunction = read('supabase/functions/tijarati-assistant/index.ts');
assert.match(aiFunction, /supabase\.auth\.getUser/);
assert.match(aiFunction, /OPENAI_API_KEY/);
assert.match(aiFunction, /gpt-4\.1-mini/);
assert.doesNotMatch(aiFunction, /SUPABASE_SERVICE_ROLE_KEY/);
console.log('TIJARATI smoke checks passed');
assert.match(html, /id="analyzeProductPhoto"/);
assert.match(html, /id="aiImage"/);
assert.match(js, /imageAsDataUrl/);
assert.match(js, /task:'product_photo'/);
assert.match(aiFunction, /imageData/);
assert.match(aiFunction, /image_url/);
assert.match(aiFunction, /product_photo/);
const ownerMigration = read('supabase/migrations/20261119020000_lock_single_platform_owner_email.sql');
assert.match(ownerMigration, /user_roles_single_platform_owner/);
assert.match(ownerMigration, /adamsaadoutlook@gmail\.com/);
assert.match(ownerMigration, /BEFORE INSERT OR UPDATE OF role, user_id/);
assert.match(ownerMigration, /SECURITY DEFINER/);
const ownerBootstrap = read('supabase/bootstrap_owner.sql');
assert.match(ownerBootstrap, /adamsaadoutlook@gmail\.com/);
assert.doesNotMatch(ownerBootstrap, /REPLACE-WITH-OWNER-USER-UUID/);

const v23Migration = read('supabase/migrations/20261119030000_enforce_single_owner_email_v23.sql');
assert.match(v23Migration, /adamsaadoutlook@gmail\.com/);
assert.match(v23Migration, /CREATE UNIQUE INDEX IF NOT EXISTS user_roles_single_platform_owner/);
assert.match(v23Migration, /A non-configured owner exists/);
assert.doesNotMatch(v23Migration, /DELETE FROM public\.user_roles/);

assert.match(js, /const tabAllowed=tab=>/);
assert.match(js, /function updateNavigation\(\)/);
for (const navId of ['sellerNav','ordersNav','messagesNav','assistantNav']) assert.match(html, new RegExp(`id="${navId}" class="hidden"`));
assert.equal(pkg.version, '2.5.0');
