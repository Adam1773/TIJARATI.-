# TIJARATI AI Copilot

The authenticated Supabase Edge Function `tijarati-assistant` powers the in-app AI copilot. It supports Arabic, English, Sorani Kurdish and Kurmanji Kurdish according to the selected UI language.

## Capabilities in this build
- General help for customers, merchants and marketplace workflows.
- Image understanding: a user can attach or capture a JPEG, PNG or WEBP image and ask questions about it.
- Merchant product-photo analysis: proposes a product title, factual description, text category hint, condition hint and photography advice; the app fills editable title/description fields for merchant review.
- Practical guidance for product photos, product listing quality, catalog presentation, merchandising and display wording.
- The merchant must verify all AI suggestions and manually choose category, price, stock and condition before saving. AI does not publish, upload, edit or alter a product by itself.

## Hosted deployment status (19 November 2026)
The `tijarati-assistant` Edge Function has been deployed to the connected TIJARATI Supabase project and verified as **ACTIVE** with JWT verification enabled. The `OPENAI_API_KEY` secret has **not** been configured through this workspace, so AI requests will return a configuration error until the owner adds the key.

To activate it, open Supabase Dashboard → Project Settings → Edge Functions → Secrets (or the Edge Function secrets page), add `OPENAI_API_KEY` with your own OpenAI API key, and save. Do not paste the key into ChatGPT, the app, `app.js`, or source control. Provider usage may incur charges.

For a later redeploy from a local checkout:
```bash
supabase link --project-ref qbqlmqyxkotxoowejyso
supabase functions deploy tijarati-assistant
```
The function validates the caller's Supabase session. The OpenAI key is held only as an Edge Function secret and must never be added to frontend files.

## Image and privacy notes
- Accepted image formats: JPEG, PNG and WEBP, up to 4 MB.
- The selected image is sent to the configured AI provider through the authenticated Edge Function for analysis. It is not automatically added to the product's image storage by this analysis action; the normal product save flow uploads the chosen original image separately.
- Do not upload identity documents, payment cards, private images or other sensitive material for product analysis.
- Set provider-side spend limits and monitor usage. Provider usage may incur charges.

## Limits
The assistant can analyze, explain, draft and recommend. It cannot physically take photographs, retouch image pixels, autonomously publish listings, set prices, change stock, place orders, access private order records, or perform actions on behalf of the user. These actions require explicit app workflows and user confirmation. Image analysis and AI suggestions can be wrong; users must verify visible product facts, brand/model, condition and specifications.

A working AI service requires the deployed Edge Function and `OPENAI_API_KEY` secret. The function is deployed; the secret remains the one manual activation requirement. Kurdish wording and image-analysis quality require native-speaker and real-device QA before public launch.
