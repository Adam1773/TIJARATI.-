# TIJARATI V21 – localization and marketplace usability update

## Included in this package
- Retains the V20 marketplace, Supabase integration, role workflows, delivery workflows, AI assistant function, and Android GitHub Actions workflow.
- Expands the authored interface glossary for English, Sorani Kurdish, and Kurmanji across account, cart, checkout, store, delivery, and administration labels.
- Adds marketplace product sorting: newest, lowest price, highest price, and stock quantity.
- Keeps Arabic as the default language and preserves the four language choices: Arabic, English, Sorani Kurdish, and Kurmanji.
- No administrator password or secret API key is embedded in the client source.

## Important completion requirements
- This is a source-code update, not a built APK.
- Translation coverage is improved but must still be reviewed screen-by-screen, especially server-generated messages, database errors, and user-generated content.
- The AI Edge Function requires the owner to configure `OPENAI_API_KEY` in Supabase Edge Function Secrets. Do not place this key in app.js or share it in chat.
- The single-owner bootstrap requires the actual Supabase Auth user UUID and must be executed by an authorized project owner. Email/password must not be hardcoded in source code.
- Apply pending Supabase migrations to the connected project before production use and run security checks.
