-- Run once in Supabase SQL Editor after the intended account has registered
-- and verified its email. This grants the owner role to that exact email only.
-- No password is stored or changed by this script.
DO $block$
DECLARE
  v_owner_id uuid;
BEGIN
  SELECT id INTO v_owner_id
  FROM auth.users
  WHERE lower(email) = 'adamsaadoutlook@gmail.com'
  LIMIT 1;

  IF v_owner_id IS NULL THEN
    RAISE EXCEPTION 'Register and verify adamsaadoutlook@gmail.com in Supabase Auth first.';
  END IF;

  IF EXISTS (
    SELECT 1 FROM public.user_roles WHERE role = 'owner' AND user_id <> v_owner_id
  ) THEN
    RAISE EXCEPTION 'Another owner role exists. Review it before assigning the single owner.';
  END IF;

  INSERT INTO public.user_roles (user_id, role)
  VALUES (v_owner_id, 'owner')
  ON CONFLICT (user_id, role) DO NOTHING;

  UPDATE public.profiles
  SET role = 'owner', is_active = true
  WHERE id = v_owner_id;
END;
$block$;

-- Verify the single configured owner:
SELECT au.email, ur.user_id, ur.role
FROM public.user_roles ur
JOIN auth.users au ON au.id = ur.user_id
WHERE ur.role = 'owner';
