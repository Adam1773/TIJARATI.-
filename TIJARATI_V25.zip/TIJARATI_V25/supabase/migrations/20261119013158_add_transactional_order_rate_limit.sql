CREATE SCHEMA IF NOT EXISTS private;
REVOKE ALL ON SCHEMA private FROM PUBLIC, anon, authenticated;
CREATE OR REPLACE FUNCTION private.guard_order_rate_limit()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path TO ''
AS $function$
DECLARE v_recent integer;
BEGIN
  IF NEW.buyer_id IS NULL THEN RAISE EXCEPTION 'Buyer is required' USING errcode='22023'; END IF;
  PERFORM pg_advisory_xact_lock(hashtextextended(NEW.buyer_id::text, 918273));
  SELECT count(*) INTO v_recent FROM public.orders o
  WHERE o.buyer_id=NEW.buyer_id AND o.created_at >= now() - interval '10 minutes';
  IF v_recent >= 5 THEN
    RAISE EXCEPTION 'Order rate limit exceeded. Please wait before placing another order.' USING errcode='P0001';
  END IF;
  RETURN NEW;
END;
$function$;
REVOKE ALL ON FUNCTION private.guard_order_rate_limit() FROM PUBLIC, anon, authenticated;
DROP TRIGGER IF EXISTS orders_rate_limit_guard ON public.orders;
CREATE TRIGGER orders_rate_limit_guard BEFORE INSERT ON public.orders
FOR EACH ROW EXECUTE FUNCTION private.guard_order_rate_limit();
