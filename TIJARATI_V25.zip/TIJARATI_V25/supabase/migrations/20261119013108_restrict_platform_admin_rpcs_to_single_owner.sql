-- These RPCs are intentionally callable by authenticated users, but only the one
-- platform owner can pass the server-side authorization check.
CREATE OR REPLACE FUNCTION public.admin_add_delivery_agent(p_email text, p_service_areas text[] DEFAULT '{}'::text[], p_notes text DEFAULT NULL::text)
RETURNS uuid LANGUAGE plpgsql SECURITY DEFINER SET search_path TO '' AS $function$
DECLARE v_user uuid;
BEGIN
 IF NOT EXISTS (SELECT 1 FROM public.user_roles ur WHERE ur.user_id=auth.uid() AND ur.role='owner') THEN RAISE EXCEPTION 'Platform owner access required' USING errcode='42501'; END IF;
 SELECT id INTO v_user FROM auth.users WHERE lower(email)=lower(trim(p_email)) LIMIT 1;
 IF v_user IS NULL THEN RAISE EXCEPTION 'No account found for this email. Ask the person to register first.' USING errcode='P0002'; END IF;
 INSERT INTO public.platform_delivery_agents(user_id,status,service_areas,notes,created_by) VALUES(v_user,'active',coalesce(p_service_areas,'{}'::text[]),p_notes,auth.uid())
 ON CONFLICT(user_id) DO UPDATE SET status='active',service_areas=excluded.service_areas,notes=excluded.notes,updated_at=now();
 INSERT INTO public.user_roles(user_id,role,assigned_by) VALUES(v_user,'delivery_agent',auth.uid()) ON CONFLICT(user_id,role) DO NOTHING;
 RETURN v_user;
END $function$;
CREATE OR REPLACE FUNCTION public.admin_assign_delivery_order(p_order_id uuid,p_agent_id uuid)
RETURNS uuid LANGUAGE plpgsql SECURITY DEFINER SET search_path TO '' AS $function$
DECLARE v_assignment uuid;
BEGIN
 IF NOT EXISTS (SELECT 1 FROM public.user_roles ur WHERE ur.user_id=auth.uid() AND ur.role='owner') THEN RAISE EXCEPTION 'Platform owner access required' USING errcode='42501'; END IF;
 IF NOT EXISTS (SELECT 1 FROM public.platform_delivery_agents da WHERE da.user_id=p_agent_id AND da.status='active') THEN RAISE EXCEPTION 'Active delivery agent not found' USING errcode='P0002'; END IF;
 IF NOT EXISTS (SELECT 1 FROM public.orders o WHERE o.id=p_order_id AND o.status IN ('confirmed','preparing','out_for_delivery')) THEN RAISE EXCEPTION 'Order is not ready for delivery assignment' USING errcode='22023'; END IF;
 INSERT INTO public.delivery_assignments(order_id,delivery_agent_id,status,tracking_code,assigned_at,delivery_provider,assigned_by)
 VALUES(p_order_id,p_agent_id,'assigned','TJ-'||upper(substr(replace(gen_random_uuid()::text,'-',''),1,10)),now(),'platform',auth.uid())
 ON CONFLICT(order_id) DO UPDATE SET delivery_agent_id=excluded.delivery_agent_id,status='assigned',tracking_code=coalesce(public.delivery_assignments.tracking_code,excluded.tracking_code),assigned_at=now(),delivery_provider='platform',assigned_by=auth.uid(),updated_at=now()
 RETURNING id INTO v_assignment;
 RETURN v_assignment;
END $function$;
CREATE OR REPLACE FUNCTION public.admin_list_delivery_agents()
RETURNS TABLE(user_id uuid,email text,full_name text,status text,service_areas text[],notes text)
LANGUAGE plpgsql SECURITY DEFINER SET search_path TO '' AS $function$
BEGIN
 IF NOT EXISTS (SELECT 1 FROM public.user_roles ur WHERE ur.user_id=auth.uid() AND ur.role='owner') THEN RAISE EXCEPTION 'Platform owner access required' USING errcode='42501'; END IF;
 RETURN QUERY SELECT da.user_id,au.email,pr.full_name,da.status,da.service_areas,da.notes FROM public.platform_delivery_agents da JOIN auth.users au ON au.id=da.user_id LEFT JOIN public.profiles pr ON pr.id=da.user_id ORDER BY da.created_at DESC;
END $function$;
CREATE OR REPLACE FUNCTION public.admin_set_delivery_agent_status(p_user_id uuid,p_status text)
RETURNS boolean LANGUAGE plpgsql SECURITY DEFINER SET search_path TO '' AS $function$
BEGIN
 IF NOT EXISTS (SELECT 1 FROM public.user_roles ur WHERE ur.user_id=auth.uid() AND ur.role='owner') THEN RAISE EXCEPTION 'Platform owner access required' USING errcode='42501'; END IF;
 IF p_status NOT IN ('active','suspended') THEN RAISE EXCEPTION 'Invalid status' USING errcode='22023'; END IF;
 UPDATE public.platform_delivery_agents SET status=p_status,updated_at=now() WHERE user_id=p_user_id;
 IF NOT FOUND THEN RAISE EXCEPTION 'Delivery agent not found' USING errcode='P0002'; END IF;
 RETURN true;
END $function$;
