-- V23: enforce the single configured platform owner without deleting existing roles.
-- The currently connected production database was checked first and contains
-- exactly the configured owner email. If a conflicting owner exists elsewhere,
-- this migration fails safely instead of silently deleting that account's role.
DO $$
BEGIN
  IF EXISTS (
    SELECT 1 FROM public.user_roles ur
    JOIN auth.users au ON au.id = ur.user_id
    WHERE ur.role = 'owner'
      AND lower(au.email) <> 'adamsaadoutlook@gmail.com'
  ) THEN
    RAISE EXCEPTION 'A non-configured owner exists. Review manually; no roles were changed.';
  END IF;
END $$;

CREATE UNIQUE INDEX IF NOT EXISTS user_roles_single_platform_owner
ON public.user_roles ((role)) WHERE role = 'owner';

CREATE OR REPLACE FUNCTION public.enforce_tijarati_single_owner_email()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path = '' AS $function$
DECLARE v_email text;
BEGIN
  IF NEW.role = 'owner' THEN
    SELECT lower(u.email) INTO v_email FROM auth.users AS u WHERE u.id = NEW.user_id;
    IF v_email IS DISTINCT FROM 'adamsaadoutlook@gmail.com' THEN
      RAISE EXCEPTION 'Only the configured platform owner account may receive owner role.' USING ERRCODE = '42501';
    END IF;
  END IF;
  RETURN NEW;
END;
$function$;
REVOKE ALL ON FUNCTION public.enforce_tijarati_single_owner_email() FROM PUBLIC;
DROP TRIGGER IF EXISTS trg_enforce_tijarati_single_owner_email ON public.user_roles;
CREATE TRIGGER trg_enforce_tijarati_single_owner_email
BEFORE INSERT OR UPDATE OF role, user_id ON public.user_roles
FOR EACH ROW EXECUTE FUNCTION public.enforce_tijarati_single_owner_email();
