REVOKE INSERT, UPDATE, DELETE, TRUNCATE, REFERENCES, TRIGGER ON ALL TABLES IN SCHEMA public FROM anon;
GRANT SELECT ON public.categories, public.products, public.stores, public.store_delivery_areas TO anon;
