alter table public.orders drop constraint if exists orders_status_check;
alter table public.orders add constraint orders_status_check check (status = any(array['pending','confirmed','preparing','out_for_delivery','shipped','delivered','cancelled','refunded']::text[]));
alter table public.order_status_history drop constraint if exists order_status_history_status_check;
alter table public.order_status_history add constraint order_status_history_status_check check (status = any(array['pending','confirmed','preparing','out_for_delivery','shipped','delivered','cancelled','refunded']::text[]));
