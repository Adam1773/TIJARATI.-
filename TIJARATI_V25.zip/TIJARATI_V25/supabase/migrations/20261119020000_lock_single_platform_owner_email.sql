-- TIJARATI V22: enforce the one permitted platform-owner identity.
-- The account must first exist in Supabase Auth. This migration does not create
-- credentials and never stores a password. All other owner grants are rejected.

-- Remove any accidental owner role assigned to a different email first.
DELETE FROM public.user_roles ur
USING auth.users au
WHERE ur.user_id = au.id
  AND ur.role = 'owner'
  AND lower(au.email) <> 'adamsaadoutlook@gmail.com';

CREATE UNIQUE INDEX IF NOT EXISTS user_roles_single_platform_owner
ON public.user_roles ((role)) WHERE role = 'owner';

CREATE OR REPLACE FUNCTION public.enforce_tijarati_single_owner_email()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = ''
AS $function$
DECLARE
  v_email text;
BEGIN
  IF NEW.role = 'owner' THEN
    SELECT lower(u.email) INTO v_email
    FROM auth.users AS u
    WHERE u.id = NEW.user_id;

    IF v_email IS DISTINCT FROM 'adamsaadoutlook@gmail.com' THEN
      RAISE EXCEPTION 'Only the configured platform owner account may receive owner role.'
        USING ERRCODE = '42501';
    END IF;
  END IF;
  RETURN NEW;
END;
$function$;

DROP TRIGGER IF EXISTS trg_enforce_tijarati_single_owner_email ON public.user_roles;
CREATE TRIGGER trg_enforce_tijarati_single_owner_email
BEFORE INSERT OR UPDATE OF role, user_id ON public.user_roles
FOR EACH ROW EXECUTE FUNCTION public.enforce_tijarati_single_owner_email();

