-- Atomic checkout: server-calculated prices, delivery coverage, stock and commission.
-- Clients must call this RPC instead of inserting orders/order_items directly.
create or replace function public.place_order(
  p_store_id uuid,
  p_delivery_city_id uuid,
  p_recipient_name text,
  p_recipient_phone text,
  p_delivery_address text,
  p_delivery_notes text,
  p_items jsonb
) returns table(order_id uuid, order_number bigint, total numeric, currency public.price_currency)
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_customer uuid := auth.uid();
  v_store public.stores%rowtype;
  v_currency public.price_currency;
  v_subtotal numeric(14,2) := 0;
  v_delivery_fee numeric(14,2) := 0;
  v_commission numeric(14,2) := 0;
  v_order_id uuid;
  v_order_number bigint;
  v_item jsonb;
  v_product public.products%rowtype;
  v_qty integer;
  v_unit numeric(14,2);
  v_rows integer;
begin
  if v_customer is null then raise exception 'Authentication required'; end if;
  if length(trim(coalesce(p_recipient_name,''))) < 2
     or length(trim(coalesce(p_recipient_phone,''))) < 7
     or length(trim(coalesce(p_delivery_address,''))) < 5 then
    raise exception 'Recipient name, valid phone and full address are required';
  end if;
  if jsonb_typeof(p_items) <> 'array' or jsonb_array_length(p_items) = 0 then
    raise exception 'Cart is empty';
  end if;

  select * into v_store from public.stores
   where id = p_store_id and is_active = true;
  if not found then raise exception 'Store is unavailable'; end if;

  -- Currency and coverage fee are determined from the actual cart below.

  for v_item in select value from jsonb_array_elements(p_items) loop
    if (v_item->>'product_id') is null or (v_item->>'quantity') is null then
      raise exception 'Each cart item needs product_id and quantity';
    end if;
    v_qty := (v_item->>'quantity')::integer;
    if v_qty < 1 or v_qty > 10000 then raise exception 'Invalid quantity'; end if;
    select * into v_product from public.products
     where id = (v_item->>'product_id')::uuid
       and store_id = p_store_id and is_active = true
     for update;
    if not found then raise exception 'A product is unavailable'; end if;
    if v_currency is null then v_currency := v_product.currency;
    elsif v_currency <> v_product.currency then raise exception 'A single order cannot mix currencies'; end if;
    if v_product.stock_qty < v_qty then raise exception 'Insufficient stock for product %', v_product.name_ar; end if;
    v_unit := case when v_qty >= v_product.wholesale_min_qty and v_product.wholesale_price is not null
                   then v_product.wholesale_price else v_product.price end;
    v_subtotal := v_subtotal + (v_unit * v_qty);
  end loop;

  select case when v_currency = 'IQD' then fee_iqd else fee_usd end
    into v_delivery_fee
    from public.delivery_coverage
   where is_active = true and to_city_id = p_delivery_city_id
     and (store_id = p_store_id or (store_id is null and company_id is not null))
   order by case when store_id = p_store_id then 0 else 1 end
   limit 1;
  if not found then raise exception 'Delivery is not available to the selected city'; end if;

  v_commission := round(v_subtotal * v_store.commission_rate / 100, 2);
  insert into public.orders(customer_id,store_id,delivery_city_id,recipient_name,recipient_phone,
    delivery_address,delivery_notes,currency,subtotal,delivery_fee,commission_amount,total)
  values(v_customer,p_store_id,p_delivery_city_id,trim(p_recipient_name),trim(p_recipient_phone),
    trim(p_delivery_address),nullif(trim(coalesce(p_delivery_notes,'')),''),v_currency,
    v_subtotal,v_delivery_fee,v_commission,v_subtotal+v_delivery_fee)
  returning id, orders.order_number into v_order_id,v_order_number;

  for v_item in select value from jsonb_array_elements(p_items) loop
    v_qty := (v_item->>'quantity')::integer;
    select * into v_product from public.products
     where id = (v_item->>'product_id')::uuid and store_id = p_store_id
     for update;
    v_unit := case when v_qty >= v_product.wholesale_min_qty and v_product.wholesale_price is not null
                   then v_product.wholesale_price else v_product.price end;
    update public.products set stock_qty = stock_qty - v_qty, updated_at = now()
     where id = v_product.id and stock_qty >= v_qty;
    get diagnostics v_rows = row_count;
    if v_rows <> 1 then raise exception 'Stock changed during checkout; please retry'; end if;
    insert into public.order_items(order_id,product_id,product_name,quantity,unit_price,line_total)
    values(v_order_id,v_product.id,v_product.name_ar,v_qty,v_unit,v_unit*v_qty);
  end loop;

  insert into public.order_status_history(order_id,changed_by,new_status,note)
  values(v_order_id,v_customer,'pending','Order created; cash on delivery');
  insert into public.commission_ledger(order_id,store_id,amount,currency)
  values(v_order_id,p_store_id,v_commission,v_currency);

  return query select v_order_id,v_order_number,v_subtotal+v_delivery_fee,v_currency;
end;
$$;

revoke all on function public.place_order(uuid,uuid,text,text,text,text,jsonb) from public, anon;
grant execute on function public.place_order(uuid,uuid,text,text,text,text,jsonb) to authenticated;
-- Prevent clients from bypassing server-side price/stock calculations.
revoke insert on public.orders, public.order_items from authenticated;
