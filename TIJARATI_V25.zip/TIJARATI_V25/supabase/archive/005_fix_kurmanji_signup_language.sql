CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO ''
AS $function$
BEGIN
  INSERT INTO public.profiles (id, full_name, phone, preferred_language)
  VALUES (
    NEW.id,
    NULLIF(NEW.raw_user_meta_data ->> 'full_name',''),
    NULLIF(NEW.phone,''),
    CASE
      WHEN NEW.raw_user_meta_data ->> 'preferred_language' IN ('ar','en','ckb','kmr')
        THEN NEW.raw_user_meta_data ->> 'preferred_language'
      ELSE 'ar'
    END
  )
  ON CONFLICT (id) DO NOTHING;

  -- Keep the existing single-owner bootstrap rule; all other users start as customers.
  IF lower(coalesce(NEW.email, '')) = 'adamsaadoutlok@gmail.com' THEN
    INSERT INTO public.user_roles (user_id, role)
    VALUES (NEW.id, 'owner')
    ON CONFLICT (user_id, role) DO NOTHING;
  ELSE
    INSERT INTO public.user_roles (user_id, role)
    VALUES (NEW.id, 'customer')
    ON CONFLICT (user_id, role) DO NOTHING;
  END IF;
  RETURN NEW;
END;
$function$;
