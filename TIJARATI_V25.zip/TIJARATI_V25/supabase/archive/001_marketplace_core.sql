-- TIJARATI marketplace core schema (PostgreSQL / Supabase)
create extension if not exists pgcrypto;
create type public.app_role as enum ('owner','employee','merchant','distributor','delivery_agent','customer');
create type public.order_status as enum ('pending','confirmed','processing','ready_for_pickup','in_transit','delivered','cancelled','returned');
create type public.payment_method as enum ('cash_on_delivery');
create type public.payment_status as enum ('unpaid','collected','refunded');
create type public.price_currency as enum ('IQD','USD');

create table public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text not null default '', phone text unique,
  role public.app_role not null default 'customer',
  city_id uuid, is_active boolean not null default true,
  created_at timestamptz not null default now(), updated_at timestamptz not null default now()
);
create table public.cities (
  id uuid primary key default gen_random_uuid(), name_ar text not null,
  name_en text, name_ckb text, name_kmr text,
  country_code char(2) not null default 'IQ', is_active boolean not null default true,
  unique(name_ar,country_code)
);
alter table public.profiles add constraint profiles_city_fk foreign key(city_id) references public.cities(id);
create table public.stores (
  id uuid primary key default gen_random_uuid(), owner_id uuid not null references public.profiles(id),
  name text not null, description text, city_id uuid references public.cities(id),
  is_verified boolean not null default false, is_active boolean not null default true,
  commission_rate numeric(5,2) not null default 0 check(commission_rate between 0 and 100),
  created_at timestamptz not null default now()
);
create table public.store_members (
  store_id uuid not null references public.stores(id) on delete cascade,
  user_id uuid not null references public.profiles(id) on delete cascade,
  member_role public.app_role not null check(member_role in ('employee','merchant','distributor','delivery_agent')),
  primary key(store_id,user_id)
);
create table public.delivery_companies (
  id uuid primary key default gen_random_uuid(), name text not null,
  contact_phone text, is_platform_company boolean not null default false,
  is_active boolean not null default true, created_at timestamptz not null default now()
);
create table public.delivery_coverage (
  id uuid primary key default gen_random_uuid(), company_id uuid references public.delivery_companies(id) on delete cascade,
  store_id uuid references public.stores(id) on delete cascade,
  from_city_id uuid references public.cities(id), to_city_id uuid not null references public.cities(id),
  fee_iqd numeric(14,2) not null default 0 check(fee_iqd>=0), fee_usd numeric(12,2) not null default 0 check(fee_usd>=0),
  estimated_days integer check(estimated_days is null or estimated_days>=0), is_active boolean not null default true,
  check(company_id is not null or store_id is not null)
);
create table public.products (
  id uuid primary key default gen_random_uuid(), store_id uuid not null references public.stores(id) on delete cascade,
  seller_id uuid not null references public.profiles(id), name_ar text not null, name_en text, name_ckb text, name_kmr text,
  description text, category text, sku text, price numeric(14,2) not null check(price>=0),
  currency public.price_currency not null, stock_qty integer not null default 0 check(stock_qty>=0),
  wholesale_min_qty integer not null default 1 check(wholesale_min_qty>=1), wholesale_price numeric(14,2) check(wholesale_price is null or wholesale_price>=0),
  image_urls text[] not null default '{}', is_active boolean not null default true,
  created_at timestamptz not null default now(), updated_at timestamptz not null default now()
);
create index products_store_active_idx on public.products(store_id,is_active);
create index products_category_idx on public.products(category);
create table public.orders (
  id uuid primary key default gen_random_uuid(), order_number bigint generated always as identity unique,
  customer_id uuid not null references public.profiles(id), store_id uuid not null references public.stores(id),
  delivery_city_id uuid not null references public.cities(id), recipient_name text not null,
  recipient_phone text not null, delivery_address text not null, delivery_notes text,
  status public.order_status not null default 'pending', payment_method public.payment_method not null default 'cash_on_delivery',
  payment_status public.payment_status not null default 'unpaid', currency public.price_currency not null,
  subtotal numeric(14,2) not null check(subtotal>=0), delivery_fee numeric(14,2) not null default 0 check(delivery_fee>=0),
  commission_amount numeric(14,2) not null default 0 check(commission_amount>=0), total numeric(14,2) not null check(total>=0),
  delivery_company_id uuid references public.delivery_companies(id), delivery_agent_id uuid references public.profiles(id),
  delivered_at timestamptz, collected_at timestamptz, created_at timestamptz not null default now(), updated_at timestamptz not null default now()
);
create index orders_customer_idx on public.orders(customer_id,created_at desc);
create index orders_store_idx on public.orders(store_id,created_at desc);
create table public.order_items (
  id uuid primary key default gen_random_uuid(), order_id uuid not null references public.orders(id) on delete cascade,
  product_id uuid not null references public.products(id), product_name text not null,
  quantity integer not null check(quantity>0), unit_price numeric(14,2) not null check(unit_price>=0),
  line_total numeric(14,2) not null check(line_total>=0)
);
create table public.order_status_history (
  id uuid primary key default gen_random_uuid(), order_id uuid not null references public.orders(id) on delete cascade,
  changed_by uuid references public.profiles(id), old_status public.order_status, new_status public.order_status not null,
  note text, created_at timestamptz not null default now()
);
create table public.messages (
  id uuid primary key default gen_random_uuid(), order_id uuid references public.orders(id) on delete set null,
  sender_id uuid not null references public.profiles(id), recipient_id uuid not null references public.profiles(id),
  body text not null check(length(trim(body)) between 1 and 5000), read_at timestamptz,
  created_at timestamptz not null default now()
);
create index messages_inbox_idx on public.messages(recipient_id,created_at desc);
create table public.commission_ledger (
  id uuid primary key default gen_random_uuid(), order_id uuid not null unique references public.orders(id),
  store_id uuid not null references public.stores(id), amount numeric(14,2) not null check(amount>=0),
  currency public.price_currency not null, settled_at timestamptz, created_at timestamptz not null default now()
);

-- New signups are always customers. Privileged roles are assigned only by the platform owner through trusted server tooling.
create or replace function public.handle_new_user() returns trigger language plpgsql security definer set search_path = '' as $$
begin
  insert into public.profiles(id,full_name,phone,role)
  values(new.id, coalesce(new.raw_user_meta_data->>'full_name',''), nullif(new.raw_user_meta_data->>'phone',''), 'customer')
  on conflict(id) do nothing;
  return new;
end; $$;
create trigger on_auth_user_created after insert on auth.users for each row execute procedure public.handle_new_user();

-- Authorization helpers use trusted profiles.role, never editable user metadata.
create or replace function public.is_owner() returns boolean language sql stable security definer set search_path = '' as $$
 select exists(select 1 from public.profiles p where p.id = (select auth.uid()) and p.role='owner' and p.is_active);
$$;
create or replace function public.can_manage_store(target_store uuid) returns boolean language sql stable security definer set search_path = '' as $$
 select public.is_owner() or exists(
  select 1 from public.stores s where s.id=target_store and s.owner_id=(select auth.uid())
 ) or exists(select 1 from public.store_members sm where sm.store_id=target_store and sm.user_id=(select auth.uid()) and sm.member_role in ('employee','merchant'));
$$;

alter table public.profiles enable row level security;
alter table public.cities enable row level security;
alter table public.stores enable row level security;
alter table public.store_members enable row level security;
alter table public.delivery_companies enable row level security;
alter table public.delivery_coverage enable row level security;
alter table public.products enable row level security;
alter table public.orders enable row level security;
alter table public.order_items enable row level security;
alter table public.order_status_history enable row level security;
alter table public.messages enable row level security;
alter table public.commission_ledger enable row level security;

create policy "profiles read self or owner" on public.profiles for select to authenticated using(id=(select auth.uid()) or public.is_owner());
create policy "profiles update self safe fields" on public.profiles for update to authenticated using(id=(select auth.uid()) or public.is_owner()) with check(id=(select auth.uid()) or public.is_owner());
create policy "cities visible" on public.cities for select to anon,authenticated using(is_active or public.is_owner());
create policy "stores visible" on public.stores for select to anon,authenticated using(is_active or public.can_manage_store(id));
create policy "stores owner manage" on public.stores for all to authenticated using(owner_id=(select auth.uid()) or public.is_owner()) with check(owner_id=(select auth.uid()) or public.is_owner());
create policy "store members read related" on public.store_members for select to authenticated using(user_id=(select auth.uid()) or public.can_manage_store(store_id));
create policy "store members manage" on public.store_members for all to authenticated using(public.can_manage_store(store_id)) with check(public.can_manage_store(store_id));
create policy "delivery companies visible" on public.delivery_companies for select to anon,authenticated using(is_active or public.is_owner());
create policy "coverage visible" on public.delivery_coverage for select to anon,authenticated using(is_active or public.is_owner());
create policy "products visible" on public.products for select to anon,authenticated using(is_active or public.can_manage_store(store_id));
create policy "products manage" on public.products for all to authenticated using(seller_id=(select auth.uid()) or public.can_manage_store(store_id)) with check(seller_id=(select auth.uid()) or public.can_manage_store(store_id));
create policy "orders read participants" on public.orders for select to authenticated using(customer_id=(select auth.uid()) or public.can_manage_store(store_id) or delivery_agent_id=(select auth.uid()) or public.is_owner());
create policy "customer create own orders" on public.orders for insert to authenticated with check(customer_id=(select auth.uid()) and status='pending' and payment_method='cash_on_delivery' and payment_status='unpaid');
create policy "orders update authorized" on public.orders for update to authenticated using(public.can_manage_store(store_id) or delivery_agent_id=(select auth.uid()) or public.is_owner()) with check(public.can_manage_store(store_id) or delivery_agent_id=(select auth.uid()) or public.is_owner());
create policy "order items read participants" on public.order_items for select to authenticated using(exists(select 1 from public.orders o where o.id=order_id and (o.customer_id=(select auth.uid()) or public.can_manage_store(o.store_id) or o.delivery_agent_id=(select auth.uid()) or public.is_owner())));
create policy "order items create own pending order" on public.order_items for insert to authenticated with check(exists(select 1 from public.orders o where o.id=order_id and o.customer_id=(select auth.uid()) and o.status='pending'));
create policy "status history read participants" on public.order_status_history for select to authenticated using(exists(select 1 from public.orders o where o.id=order_id and (o.customer_id=(select auth.uid()) or public.can_manage_store(o.store_id) or o.delivery_agent_id=(select auth.uid()) or public.is_owner())));
create policy "status history authorized insert" on public.order_status_history for insert to authenticated with check(changed_by=(select auth.uid()) and exists(select 1 from public.orders o where o.id=order_id and (public.can_manage_store(o.store_id) or o.delivery_agent_id=(select auth.uid()) or public.is_owner())));
create policy "messages participants" on public.messages for select to authenticated using(sender_id=(select auth.uid()) or recipient_id=(select auth.uid()) or public.is_owner());
create policy "messages send as self" on public.messages for insert to authenticated with check(sender_id=(select auth.uid()));
create policy "messages recipient mark read" on public.messages for update to authenticated using(recipient_id=(select auth.uid())) with check(recipient_id=(select auth.uid()));
create policy "commission owner or store manager read" on public.commission_ledger for select to authenticated using(public.is_owner() or public.can_manage_store(store_id));

-- No client-side role escalation: profiles.role is not included in any self-service insert/update path.
revoke all on public.commission_ledger from anon, authenticated;
grant select on public.commission_ledger to authenticated;
grant select on public.cities, public.stores, public.delivery_companies, public.delivery_coverage, public.products to anon, authenticated;
grant select, update on public.profiles to authenticated;
grant select, insert, update, delete on public.stores, public.store_members, public.products to authenticated;
grant select, insert, update on public.orders to authenticated;
grant select, insert on public.order_items, public.order_status_history, public.messages to authenticated;
grant update on public.messages to authenticated;

-- Enforce one permanent platform owner and prevent self-promotion through profile updates.
create unique index one_platform_owner_only on public.profiles ((role)) where role='owner';
create or replace function public.guard_profile_privileges() returns trigger language plpgsql set search_path = '' as $$
begin
  if old.role is distinct from new.role and not public.is_owner() then
    raise exception 'Only the platform owner may change account roles';
  end if;
  if old.is_active is distinct from new.is_active and not public.is_owner() then
    raise exception 'Only the platform owner may change account activation';
  end if;
  return new;
end; $$;
create trigger guard_profile_privileges_before_update before update on public.profiles
for each row execute function public.guard_profile_privileges();
revoke execute on function public.is_owner() from public, anon;
revoke execute on function public.can_manage_store(uuid) from public, anon;
grant execute on function public.is_owner() to authenticated;
grant execute on function public.can_manage_store(uuid) to authenticated;
