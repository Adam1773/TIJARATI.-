insert into public.cities(name_ar,name_en,name_ckb,name_kmr,country_code) values
('بغداد','Baghdad','بەغدا','Bexda','IQ'),
('البصرة','Basra','بەسرە','Basra','IQ'),
('الموصل','Mosul','مووسڵ','Mûsil','IQ'),
('أربيل','Erbil','هەولێر','Hewlêr','IQ'),
('السليمانية','Sulaymaniyah','سلێمانی','Silêmanî','IQ'),
('دهوك','Duhok','دهۆک','Dihok','IQ'),
('بعقوبة','Baqubah','بەعقوبە','Baqûbe','IQ'),
('كركوك','Kirkuk','کەرکووک','Kerkûk','IQ'),
('النجف','Najaf','نەجەف','Necef','IQ'),
('كربلاء','Karbala','کەربەلا','Kerbela','IQ'),
('الرمادي','Ramadi','ڕەمادی','Remadî','IQ'),
('الكوت','Kut','کوت','Kût','IQ')
on conflict(name_ar,country_code) do nothing;
