-- Remove anonymous execution from privileged RPCs.
-- Authenticated execution remains available because each function performs
-- its own auth.uid()/role/ownership checks before returning or changing data.
REVOKE EXECUTE ON FUNCTION public.admin_add_delivery_agent(text,text[],text) FROM PUBLIC, anon;
REVOKE EXECUTE ON FUNCTION public.admin_assign_delivery_order(uuid,uuid) FROM PUBLIC, anon;
REVOKE EXECUTE ON FUNCTION public.admin_list_delivery_agents() FROM PUBLIC, anon;
REVOKE EXECUTE ON FUNCTION public.admin_set_delivery_agent_status(uuid,text) FROM PUBLIC, anon;
REVOKE EXECUTE ON FUNCTION public.delivery_agent_list_my_orders() FROM PUBLIC, anon;
REVOKE EXECUTE ON FUNCTION public.delivery_agent_update_assignment(uuid,text) FROM PUBLIC, anon;
REVOKE EXECUTE ON FUNCTION public.store_owner_add_staff(uuid,text,text,jsonb) FROM PUBLIC, anon;
REVOKE EXECUTE ON FUNCTION public.store_owner_list_staff(uuid) FROM PUBLIC, anon;
REVOKE EXECUTE ON FUNCTION public.store_owner_remove_staff(uuid) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.admin_add_delivery_agent(text,text[],text) TO authenticated, service_role;
GRANT EXECUTE ON FUNCTION public.admin_assign_delivery_order(uuid,uuid) TO authenticated, service_role;
GRANT EXECUTE ON FUNCTION public.admin_list_delivery_agents() TO authenticated, service_role;
GRANT EXECUTE ON FUNCTION public.admin_set_delivery_agent_status(uuid,text) TO authenticated, service_role;
GRANT EXECUTE ON FUNCTION public.delivery_agent_list_my_orders() TO authenticated, service_role;
GRANT EXECUTE ON FUNCTION public.delivery_agent_update_assignment(uuid,text) TO authenticated, service_role;
GRANT EXECUTE ON FUNCTION public.store_owner_add_staff(uuid,text,text,jsonb) TO authenticated, service_role;
GRANT EXECUTE ON FUNCTION public.store_owner_list_staff(uuid) TO authenticated, service_role;
GRANT EXECUTE ON FUNCTION public.store_owner_remove_staff(uuid) TO authenticated, service_role;
