import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';

const cors = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
  'Access-Control-Allow-Methods': 'POST, OPTIONS',
};
const json = (body: unknown, status = 200) => new Response(JSON.stringify(body), {
  status, headers: { ...cors, 'Content-Type': 'application/json' },
});

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: cors });
  if (req.method !== 'POST') return json({ error: 'Method not allowed' }, 405);
  const auth = req.headers.get('Authorization');
  if (!auth?.startsWith('Bearer ')) return json({ error: 'Authentication required' }, 401);
  const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
  const anonKey = Deno.env.get('SUPABASE_ANON_KEY')!;
  const supabase = createClient(supabaseUrl, anonKey, { global: { headers: { Authorization: auth } } });
  const { data: { user }, error: authError } = await supabase.auth.getUser();
  if (authError || !user) return json({ error: 'Invalid session' }, 401);
  const apiKey = Deno.env.get('OPENAI_API_KEY');
  if (!apiKey) return json({ error: 'AI service is not configured. Set OPENAI_API_KEY as an Edge Function secret.' }, 503);

  let body: { message?: string; language?: string; history?: Array<{ role: string; content: string }>; imageData?: string; task?: string };
  try { body = await req.json(); } catch { return json({ error: 'Invalid JSON body' }, 400); }
  const message = String(body.message ?? '').trim();
  const imageData = typeof body.imageData === 'string' ? body.imageData : '';
  if ((!message && !imageData) || message.length > 3000) return json({ error: 'Message must contain up to 3000 characters, or include an image.' }, 400);
  if (imageData && (!/^data:image\/(jpeg|png|webp);base64,[A-Za-z0-9+/=]+$/.test(imageData) || imageData.length > 5_600_000))
    return json({ error: 'Image must be a valid JPEG, PNG or WEBP under 4MB.' }, 400);
  const language = ['ar', 'en', 'ckb', 'kmr'].includes(String(body.language)) ? String(body.language) : 'ar';
  const history = Array.isArray(body.history) ? body.history.slice(-8).filter(x =>
    x && ['user', 'assistant'].includes(x.role) && typeof x.content === 'string' && x.content.length <= 3000
  ) : [];
  const languageNames: Record<string, string> = { ar: 'Arabic', en: 'English', ckb: 'Central Kurdish (Sorani)', kmr: 'Kurmanji Kurdish' };
  const productPhotoTask = body.task === 'product_photo';
  const systemPrompt = `You are TIJARATI's in-app marketplace copilot. Reply in ${languageNames[language]}. Help customers and merchants with product photography, image understanding, product listing, clear descriptions, merchandising, catalog presentation, search wording, store setup, delivery workflow, customer support, and practical app guidance. You can inspect an attached image but cannot physically take a photo, edit/upload/publish it, change prices or stock, message users, place orders, or execute any account action. Never claim an action was completed. Never invent brand/model/specifications, prices, stock, delivery availability, legal rules or platform policies. Distinguish visible facts from uncertain guesses; ask for missing facts. Give concrete photo advice (lighting, background, framing, multiple angles) and listing/display advice. Never request passwords, OTPs, card data or API keys. ${productPhotoTask ? 'For product_photo tasks, output ONLY valid JSON with keys title, description, category_hint, condition_hint, image_tips. condition_hint must be new, used, refurbished, or unknown. Do not invent category IDs; category_hint is plain text. If uncertain, say unknown.' : ''}`;
  const messages: Array<Record<string, unknown>> = [{ role: 'system', content: systemPrompt }, ...history.slice(0, -1)];
  const userContent: Array<Record<string, unknown>> = [{ type: 'text', text: message || 'Please inspect this image and advise me.' }];
  if (imageData) userContent.push({ type: 'image_url', image_url: { url: imageData, detail: 'high' } });
  messages.push({ role: 'user', content: userContent });
  const upstream = await fetch('https://api.openai.com/v1/chat/completions', {
    method: 'POST', headers: { 'Authorization': `Bearer ${apiKey}`, 'Content-Type': 'application/json' },
    body: JSON.stringify({ model: 'gpt-4.1-mini', messages, temperature: 0.25, max_tokens: 900 }),
  });
  if (!upstream.ok) return json({ error: 'AI provider request failed', provider_status: upstream.status }, 502);
  const result = await upstream.json();
  const answer = result?.choices?.[0]?.message?.content;
  if (typeof answer !== 'string' || !answer.trim()) return json({ error: 'Empty AI response' }, 502);
  return json({ answer: answer.trim() });
});
