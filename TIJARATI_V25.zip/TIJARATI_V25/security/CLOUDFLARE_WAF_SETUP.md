# TIJARATI perimeter protection (Cloudflare)

## Current state
The application package now contains browser security headers, a strict same-origin script policy, Supabase-only API egress in CSP, and a database-side transactional order throttle (maximum five orders per authenticated buyer in ten minutes). These controls are active in the database or when the site is served with the included `_headers` file.

**Cloudflare WAF is NOT active yet.** It cannot be attached without a real public domain/zone and authorization to configure that zone. Do not claim these example rules are deployed until they are created in the Cloudflare dashboard and verified against the live hostname.

## Rules to create in Cloudflare Dashboard → Security → WAF → Custom rules
Create in this order:

1. Block invalid HTTP methods:
   `not (http.request.method in {"GET" "POST" "PUT" "PATCH" "DELETE" "OPTIONS" "HEAD"})`
   Action: Block.
2. Challenge obvious automated traffic to authentication endpoints:
   `(http.request.uri.path contains "/auth/v1/token" or http.request.uri.path contains "/auth/v1/signup") and not cf.client.bot`
   Action: Managed Challenge. Test carefully before enforcement to avoid blocking legitimate users.
3. Block common scanner paths on the application hostname:
   `(http.request.uri.path contains "/.env" or http.request.uri.path contains "/wp-admin" or http.request.uri.path contains "/phpmyadmin" or http.request.uri.path contains "/.git/")`
   Action: Block.

## Rate limiting rules
Create separate rate-limit rules (dashboard UI/API plan availability varies):

- `/auth/v1/token`: 20 requests per IP per 60 seconds; block for 10 minutes.
- `/auth/v1/signup`: 5 requests per IP per 10 minutes; managed challenge or block for 10 minutes.
- `/rest/v1/rpc/place_order_from_cart`: 10 requests per IP per 10 minutes; managed challenge/block for 10 minutes. Database also enforces 5 orders per buyer per 10 minutes.

Use `http.host eq "YOUR_APP_DOMAIN"` in each expression and scope API paths to the Supabase API hostname only if that hostname is proxied through a Cloudflare zone you control. Supabase's default `*.supabase.co` hostname is not automatically protected by your app-domain WAF. For full API perimeter protection, use a custom Supabase domain configured for Cloudflare proxying where supported, or place a controlled API gateway in front of Supabase.

## Additional account settings
- Enable leaked-password protection in Supabase Auth password security settings.
- Require email confirmation; set a strong minimum password length and MFA for the owner account.
- Keep `service_role` and any secret keys server-side only. The app must use the publishable key.
- Enable Supabase database backups and review Auth/Postgres/API logs regularly.
- Add owner MFA and rotate any credentials that may have been shared outside the owner account.
