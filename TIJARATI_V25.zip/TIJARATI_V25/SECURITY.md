# TIJARATI security controls

## Implemented
- Row Level Security enabled on all 42 public tables at the time of the latest database audit; each had at least one policy.
- Anonymous execution revoked for privileged SECURITY DEFINER RPCs; latest check found zero such functions executable by `anon`.
- Platform delivery-agent administration checks the single `owner` role (not a generic `admin` role).
- Sensitive SECURITY DEFINER functions use an empty `search_path` and explicit ownership checks.
- Checkout calculates price and stock server-side, locks product rows, enforces one store and one currency per order, and verifies delivery coverage.
- Database trigger rate-limits order creation to five per buyer per ten minutes.
- UI limits the buyer order list to the signed-in buyer and filters city results by active store delivery coverage.
- Product image storage is public-read, with upload/delete restricted to store owners or staff with `manage_products`.
- Store-scoped couriers and platform couriers have separate assignment checks; delivery companies receive orders only through owner-controlled assignment RPCs.
- Message participants are checked by RLS; authenticated users can update only the `read_at` column on messages and notifications.
- Vite bundles Supabase client locally; no runtime script from a third-party CDN.
- Content Security Policy and response headers are included for supported static hosting.

## Still required before production
- Configure Cloudflare WAF and rate limits for the real public hostname using `security/CLOUDFLARE_WAF_SETUP.md`.
- Enable Supabase leaked-password protection and owner MFA in Auth settings.
- Verify email confirmation, SMTP deliverability, backups, log alerts, and restore procedure.
- Perform external penetration testing and authenticated end-to-end tests with separate customer, merchant, staff, owner, and delivery-agent accounts.
- Confirm all security advisor warnings are understood. Authenticated `SECURITY DEFINER` RPC warnings remain because those RPCs intentionally serve authenticated workflows; each function must continue enforcing role/ownership checks internally.

No firewall or security product can guarantee protection against every attack. Keep dependencies updated and monitor logs.
